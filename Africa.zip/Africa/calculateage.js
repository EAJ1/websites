/*function CalculateAge(year){
    console.log(2023 - year);
    
}


 year  = 1998;

CalculateAge(year)

*/

function print(n){
    for (let index = 0; index <n; index++) {
       console.log(index)
        
    }
}

let n = 20;

print(n);