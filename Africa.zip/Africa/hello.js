function HelloWORLD(name, surname, age){
    let outputstr =
    "hello" + name + surname + ". You are " + age + " years old";
    console.log(outputstr);
}

let x = " John";
y = " Doe";
z = 23;

const anotherName = " Zuko"
const anotherSurname = " Jarana"
HelloWORLD(anotherName,anotherSurname,28)