function World(name, surname, age, gender){
    let outputstr = "hello "+ name+ surname + ". You are " + age + " years old" + ". You are " + gender;
    console.log(outputstr) 
}

let v = "Zuko";
x = " Jarana";
y = 29;
z = "Male";

const anotherName = "Ina";
const anotherSurname = " Ngubane";
const anotherGender = "Female";

World(anotherName,anotherSurname,22,anotherGender)