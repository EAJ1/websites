
let videoSlider = document.getElementById("videoSlider");
videoSlider.addEventListener("wheel", function (e) {
    if (e.deltaY > 0) {
        videoSlider.scrollBy(80, 0); 
    } else {
        videoSlider.scrollBy(-80, 0); 
    }
});

videoSlider.addEventListener("scroll", function () {
    let scrollPosition = videoSlider.scrollLeft;
    let videoWidth = videoSlider.offsetWidth;
    let totalWidth = videoSlider.scrollWidth;
    
    if (scrollPosition <= 0) {
        videoSlider.scrollLeft = 0;
    } else if (scrollPosition >= totalWidth - videoWidth) {
        videoSlider.scrollLeft = totalWidth - videoWidth;
    }
});


function showSection(sectionId) {
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        if (section.id === sectionId) {
            section.classList.add('active');
        } else {
            section.classList.remove('active');
        }
    });
}
  
  document.addEventListener('DOMContentLoaded', () => {
    showSection('cases');
  });

  const videoTitles = [
    "Grow Up", "BMW Stage 3", "Easy Rider", "EQ Stage", "F1 Stage",
    "IAA Making Of", "Katjes", "Mercedes Leon", "Risk", "G Class DNA",
    "Xmas", "Look Up Again"
];

const videoslider = document.getElementById("videoSlider");
const videos = document.querySelectorAll(".slider-video");

videos.forEach((video, index) => {
    const wrapper = document.createElement("div");
    wrapper.className = "video-wrapper";

    const caption = document.createElement("div");
    caption.className = "bottom-text";
    caption.textContent = videoTitles[index] || "Untitled";

    videoSlider.replaceChild(wrapper, video);
    wrapper.appendChild(video);
    wrapper.appendChild(caption);
});

